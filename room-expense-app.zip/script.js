
let balance = 15000;
let expenses = [];

window.onload = function () {
    let data = localStorage.getItem("roomExpenseData");
    if (data) {
        let parsed = JSON.parse(data);
        balance = parsed.balance;
        expenses = parsed.expenses;
    }
    render();
};

function save() {
    localStorage.setItem("roomExpenseData", JSON.stringify({ balance, expenses }));
}

function addExpense() {
    let title = document.getElementById("title").value;
    let amount = parseInt(document.getElementById("amount").value);

    if (!title || !amount) return alert("Fill all fields");
    if (amount > balance) return alert("Not enough balance");

    balance -= amount;
    expenses.push({ title, amount });
    save();
    render();

    document.getElementById("title").value = "";
    document.getElementById("amount").value = "";
}

function deleteExpense(i) {
    balance += expenses[i].amount;
    expenses.splice(i,1);
    save();
    render();
}

function render() {
    document.getElementById("total").innerText = "₹ " + balance;
    let list = document.getElementById("expenseList");
    list.innerHTML = "";
    expenses.forEach((e,i)=>{
        list.innerHTML += `<div class="note">
        <h3>${e.title}</h3>
        <p>₹ ${e.amount}</p>
        <button onclick="deleteExpense(${i})">Delete</button>
        </div>`;
    });
}

if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("service-worker.js");
}
